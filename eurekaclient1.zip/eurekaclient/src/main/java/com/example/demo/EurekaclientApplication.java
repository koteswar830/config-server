package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;


@SpringBootApplication
@EnableEurekaClient
@EnableHystrix
@RestController
public class EurekaclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaclientApplication.class, args);
	}
	
	
	
	@GetMapping("/client1")
	public String init1()
	{
		return "client1";
	}
	
	@GetMapping("/client")
	@HystrixCommand(fallbackMethod="fallbackRetrieveConfigurations") 
	public String init()
	{
		System.out.println(10/0);
		return "client1";
	}
	
	public String fallbackRetrieveConfigurations()  
	{  
	//returning the default configuration     
	return "called fall back method";
	}  

}
