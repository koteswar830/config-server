package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.utility.JwtUtil;

@SpringBootApplication
@EnableEurekaClient
public class CloudgatewayApplication {
	
	//@Autowired
	//private JwtUtil jwtUtil;

	public static void main(String[] args) {
		SpringApplication.run(CloudgatewayApplication.class, args);
	}
	
	/*
	 * @PostMapping("/authenticate") public ResponseEntity<?>
	 * createAuthenticationToken(@RequestBody AuthRequest authenticationRequest) {
	 * final String token =
	 * jwtUtil.generateToken(authenticationRequest.getUserName()); return
	 * ResponseEntity.ok(new JwtResponse(token)); }
	 */

}
