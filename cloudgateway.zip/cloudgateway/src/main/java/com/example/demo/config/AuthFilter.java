package com.example.demo.config;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.Builder;

import com.example.demo.utility.JwtUtil;
import com.google.common.net.HttpHeaders;

import reactor.core.publisher.Mono;

@Component
public class AuthFilter extends AbstractGatewayFilterFactory<AuthFilter.Config> {
	
	
	@Autowired
	private JwtUtil jwtUtil;
	
	
	public AuthFilter() {
		super(Config.class);
	}
	
	
	@Override
	public GatewayFilter apply(Config config) {
		return ((exchange, chain) -> {
				if (!exchange.getRequest().getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
					throw new RuntimeException("Missing Authorisation Header");
				}

				String authHeader = Objects.requireNonNull(exchange.getRequest().getHeaders().get(HttpHeaders.AUTHORIZATION)).get(0);
				try {
					jwtUtil.validateToken(authHeader);
				}
				catch (Exception ex) {
					//log.error("Error Validating Authentication Header", ex);
					//List<String> details = new ArrayList<>();
				//	details.add(ex.getLocalizedMessage());
					//ErrorResponseDto error = new ErrorResponseDto(new Date(), HttpStatus.UNAUTHORIZED.value(), "UNAUTHORIZED", details, exchange.getRequest().getURI().toString());
					ServerHttpResponse response = exchange.getResponse();

				//	byte[] bytes = SerializationUtils.serialize(error);
					 System.out.println("error in filter ");
					//DataBuffer buffer = exchange.getResponse().bufferFactory().wrap(bytes);
					//response.writeWith(Flux.just(buffer));
					response.setStatusCode(HttpStatus.UNAUTHORIZED);
					return response.setComplete();
				}

			return chain.filter(exchange);
		});
	}
	

	/*
	 * @Override public GatewayFilter apply(Config config) { //Custom Pre Filter.
	 * Suppose we can extract JWT and perform Authentication return (exchange,
	 * chain) -> { System.out.println("First pre filter" + exchange.getRequest());
	 * //Custom Post Filter.Suppose we can call error response handler based on
	 * error code. return chain.filter(exchange).then(Mono.fromRunnable(() -> {
	 * 
	 * String header=Objects.requireNonNull(exchange.getRequest().getHeaders().get(
	 * HttpHeaders.AUTHORIZATION)).get(0); try { jwtUtil.validateToken(header); }
	 * catch (Exception e) { System.out.println("error in filter ");
	 * ServerHttpResponse resp=exchange.getResponse();
	 * resp.setStatusCode(HttpStatus.UNAUTHORIZED); return resp.setComplete(); } //
	 * System.out.println("First post filterSS"); })); }; }
	 */

	public static class Config {
		// Put the configuration properties
	}
}
